import { useEffect, useRef, useState } from "react";
import {
  CalendarDays,
  Check,
  Church,
  Flame,
  MapPin,
  Minus,
  Navigation,
  Plus,
  Users,
  Volume2,
  VolumeX,
} from "lucide-react";
import { submitRsvp } from "@/lib/rsvp.functions";

const EVENT_AT = new Date("2026-10-25T09:00:00-03:00").getTime();
const MAP_QUERY = "-38.005279,-57.722860";
const MAPS_EMBED = `https://maps.google.com/maps?q=${MAP_QUERY}&z=16&hl=es&output=embed`;
const MAPS_DIRECTIONS = `https://www.google.com/maps/dir/?api=1&destination=${MAP_QUERY}`;
const MAPS_OPEN = `https://www.google.com/maps/search/?api=1&query=${MAP_QUERY}`;
const WELCOME =
  "Bendiciones. Has entrado a la página Puertas Abiertas al Cielo. Anótese para asistir.";

const NAV = [
  { id: "inicio", label: "Inicio" },
  { id: "aniversario", label: "Aniversario" },
  { id: "encuentro", label: "Encuentro" },
  { id: "ubicacion", label: "Ubicación" },
  { id: "asistir", label: "Asistir" },
] as const;

const TOKEN_KEY = "pac.token";
const NAME_KEY = "pac.name";
const GUESTS_KEY = "pac.guests";

type Remain = {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  done: boolean;
};

function remain(now: number): Remain {
  const diff = Math.max(0, EVENT_AT - now);
  const total = Math.floor(diff / 1000);
  return {
    days: Math.floor(total / 86400),
    hours: Math.floor((total % 86400) / 3600),
    minutes: Math.floor((total % 3600) / 60),
    seconds: total % 60,
    done: diff <= 0,
  };
}

function pad(n: number) {
  return String(n).padStart(2, "0");
}

function readToken() {
  const existing = localStorage.getItem(TOKEN_KEY);
  if (existing) return existing;
  const token = crypto.randomUUID();
  localStorage.setItem(TOKEN_KEY, token);
  return token;
}

export function EventPage({ initialTotal }: { initialTotal: number }) {
  const [active, setActive] = useState<string>("inicio");
  const [now, setNow] = useState<number | null>(null);
  const [total, setTotal] = useState(initialTotal);
  const [name, setName] = useState("");
  const [guests, setGuests] = useState(1);
  const [done, setDone] = useState(false);
  const [savedName, setSavedName] = useState("");
  const [savedGuests, setSavedGuests] = useState(1);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem(NAME_KEY);
    const count = Number(localStorage.getItem(GUESTS_KEY));
    const token = localStorage.getItem(TOKEN_KEY);
    if (!saved || !token || !Number.isInteger(count) || count < 1) return;
    setName(saved);
    setGuests(count);
    setSavedName(saved);
    setSavedGuests(count);
    setDone(true);
    submitRsvp({ data: { token, guests: count } })
      .then((result) => setTotal(result.total))
      .catch(() => {});
  }, []);

  useEffect(() => {
    const nodes = NAV.map((item) => document.getElementById(item.id)).filter(
      (node): node is HTMLElement => Boolean(node),
    );
    if (nodes.length === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-40% 0px -45% 0px", threshold: [0.15, 0.4, 0.7] },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    const trimmed = name.trim();
    if (trimmed.length < 2) {
      setError("Escribe tu nombre para anotarte.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const token = readToken();
      const result = await submitRsvp({ data: { token, guests } });
      localStorage.setItem(NAME_KEY, trimmed);
      localStorage.setItem(GUESTS_KEY, String(guests));
      setSavedName(trimmed);
      setSavedGuests(result.guests);
      setTotal(result.total);
      setDone(true);
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      setError(
        message && message.length < 140
          ? message
          : "No pudimos anotar tu lugar. Intenta de nuevo.",
      );
    } finally {
      setBusy(false);
    }
  }

  const clock = now === null ? null : remain(now);

  return (
    <div className="relative min-h-svh">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <img
          src="/hero.jpg"
          alt=""
          className="h-full w-full object-cover object-[center_62%]"
        />
        <div className="absolute inset-0 bg-bg/45" />
      </div>

      <header className="sticky top-0 z-40 border-b border-line/70 bg-bg/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
          <a
            href="#inicio"
            className="shrink-0 font-display text-sm font-bold tracking-wide text-gold"
          >
            Al Cielo
          </a>
          <nav aria-label="Secciones" className="flex min-w-0 flex-1 gap-1 overflow-x-auto">
            {NAV.map((item) => {
              const on = active === item.id;
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  aria-current={on ? "true" : undefined}
                  className={`shrink-0 rounded-full px-3 py-2 text-sm font-medium transition-colors ${
                    on ? "bg-gold text-bg-deep" : "text-muted hover:text-fg"
                  }`}
                >
                  {item.label}
                </a>
              );
            })}
          </nav>
        </div>
      </header>

      <main>
        <section id="inicio" className="scroll-mt-20">
          <div className="mx-auto flex min-h-[calc(100svh-4.25rem)] max-w-5xl flex-col justify-end px-4 pt-6 pb-6 sm:justify-center sm:px-4 sm:pt-8 sm:pb-16">
            <div className="rise max-w-xl rounded-3xl border border-line/80 bg-bg/70 p-5 shadow-2xl backdrop-blur-md sm:p-8">
              <p className="flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase">
                <Church className="size-4" aria-hidden="true" />
                Aniversario 16
              </p>
              <h1 className="gold-letters mt-3 font-display text-4xl leading-none font-bold tracking-wide uppercase sm:mt-4 sm:text-6xl">
                <span className="block">Puertas</span>
                <span className="block">Abiertas</span>
                <span className="block">al Cielo</span>
              </h1>
              <p className="mt-4 max-w-md text-base text-pretty text-fg sm:mt-5 sm:text-lg">
                Un encuentro con Dios en Batán. El fuego en tu corazón va a arder.
              </p>
              <p className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted">
                <span className="inline-flex items-center gap-2">
                  <CalendarDays className="size-4 text-gold" aria-hidden="true" />
                  Domingo 25 de octubre · 9:00
                </span>
                <span className="inline-flex items-center gap-2">
                  <MapPin className="size-4 text-gold" aria-hidden="true" />
                  Batán, Buenos Aires
                </span>
              </p>
              <div className="mt-5 flex gap-2 sm:mt-7 sm:gap-3">
                <a
                  href="#asistir"
                  className="inline-flex min-h-12 flex-1 items-center justify-center rounded-full bg-gold px-4 text-center text-sm font-semibold text-bg-deep transition-transform duration-150 ease-out sm:px-6 sm:text-base active:scale-[0.96]"
                >
                  Anotarme
                </a>
                <a
                  href="#ubicacion"
                  className="inline-flex min-h-12 flex-1 items-center justify-center rounded-full border border-gold/60 px-4 text-center text-sm font-semibold text-gold-soft transition-transform duration-150 ease-out hover:bg-gold/10 sm:px-6 sm:text-base active:scale-[0.96]"
                >
                  Cómo llegar
                </a>
              </div>
            </div>
          </div>
        </section>

        <section id="aniversario" className="scroll-mt-20 bg-bg/85 py-16 sm:py-24">
          <div className="mx-auto max-w-5xl px-4">
            <p className="text-center text-sm font-medium tracking-widest text-gold uppercase">
              Cuenta regresiva
            </p>
            <h2 className="anniversary-3d mx-auto mt-4 max-w-3xl text-center text-4xl sm:text-6xl md:text-7xl">
              El aniversario 16
            </h2>
            <p className="mx-auto mt-6 max-w-lg text-center text-pretty text-muted">
              Faltan estos días para el encuentro del domingo 25 de octubre a las 9:00.
            </p>
            {clock?.done ? (
              <p
                role="status"
                className="rise mx-auto mt-10 max-w-md rounded-2xl bg-surface px-6 py-8 text-center font-display text-2xl text-gold-soft"
              >
                El encuentro ha comenzado. Te esperamos.
              </p>
            ) : (
              <div
                className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4"
                role="timer"
                aria-label={
                  clock
                    ? `${clock.days} días, ${clock.hours} horas, ${clock.minutes} minutos y ${clock.seconds} segundos`
                    : "Cargando la cuenta regresiva"
                }
              >
                <TimeCell value={clock ? String(clock.days) : "—"} label="Días" />
                <TimeCell value={clock ? pad(clock.hours) : "—"} label="Horas" />
                <TimeCell value={clock ? pad(clock.minutes) : "—"} label="Minutos" />
                <TimeCell value={clock ? pad(clock.seconds) : "—"} label="Segundos" />
              </div>
            )}
          </div>
        </section>

        <section id="encuentro" className="scroll-mt-20 bg-bg-deep/92 py-16 sm:py-24">
          <div className="mx-auto grid max-w-5xl gap-8 px-4 lg:grid-cols-[1.2fr_0.8fr] lg:items-start">
            <div>
              <p className="flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase">
                <Flame className="size-4" aria-hidden="true" />
                El encuentro
              </p>
              <h2 className="mt-3 font-display text-3xl text-balance text-gold-soft sm:text-5xl">
                El fuego en tu corazón arderá
              </h2>
              <div className="mt-6 space-y-4 text-lg text-pretty text-fg">
                <p>Es un encuentro con Dios donde el fuego en tu corazón arderá.</p>
                <p>
                  Cuando los hijos se juntan con un mismo sentir se produce una atmósfera donde Dios
                  desata su <span className="font-display text-gold">PODER</span>.
                </p>
              </div>
              <figure className="mt-8 border-l-2 border-gold pl-5">
                <blockquote className="font-display text-xl leading-snug text-pretty text-gold-soft sm:text-2xl">
                  «Mas si desde allí buscares a Jehová tu Dios, lo hallarás, si lo buscares de todo
                  tu corazón y de toda tu alma.»
                </blockquote>
                <figcaption className="mt-3 text-sm tracking-wide text-muted uppercase">
                  Deuteronomio 4:29
                </figcaption>
              </figure>
            </div>
            <aside className="gold-stroke rounded-3xl p-6 sm:p-8">
              <p className="text-sm font-medium tracking-widest text-gold uppercase">Pastores</p>
              <p className="mt-3 font-display text-3xl leading-tight text-fg">
                Patricia y Juan Melga
              </p>
              <p className="mt-4 text-pretty text-muted">
                Te reciben en Puertas Abiertas al Cielo para el aniversario 16. Llega con el corazón
                dispuesto: cuando nos juntamos con un mismo sentir, el cielo se abre.
              </p>
              <a
                href="#asistir"
                className="mt-6 inline-flex min-h-12 items-center justify-center rounded-full bg-gold px-5 font-semibold text-bg-deep transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                Quiero estar ahí
              </a>
            </aside>
          </div>
        </section>

        <section id="ubicacion" className="scroll-mt-20 bg-bg/88 py-16 sm:py-24">
          <div className="mx-auto max-w-5xl px-4">
            <p className="flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase">
              <MapPin className="size-4" aria-hidden="true" />
              Ubicación
            </p>
            <h2 className="mt-3 font-display text-3xl text-balance text-gold-soft sm:text-5xl">
              Batán, Buenos Aires
            </h2>
            <p className="mt-4 max-w-2xl text-pretty text-muted">
              Puertas Abiertas al Cielo, Iglesia de Poder de Dios. Cerca de C. los Ortiz, B7601
              Batán, Provincia de Buenos Aires.
            </p>
            <div className="mt-8 overflow-hidden rounded-3xl border border-line bg-surface shadow-xl">
              <iframe
                title="Mapa de Puertas Abiertas al Cielo, Batán"
                src={MAPS_EMBED}
                className="h-80 w-full sm:h-96"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
              <div className="flex flex-col gap-4 border-t border-line p-5 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-sm text-muted">
                  <span className="block text-fg">C. los Ortiz, B7601 Batán</span>
                  Provincia de Buenos Aires · {MAP_QUERY}
                </p>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <a
                    href={MAPS_DIRECTIONS}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-gold px-5 font-semibold text-bg-deep transition-transform duration-150 ease-out active:scale-[0.96]"
                  >
                    <Navigation className="size-4" aria-hidden="true" />
                    Cómo llegar
                  </a>
                  <a
                    href={MAPS_OPEN}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex min-h-12 items-center justify-center rounded-full border border-line px-5 font-semibold text-fg transition-colors hover:border-gold hover:text-gold-soft"
                  >
                    Abrir en Maps
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="asistir" className="scroll-mt-20 bg-bg-deep/92 py-16 sm:py-24">
          <div className="mx-auto grid max-w-5xl gap-8 px-4 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
            <div>
              <p className="flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase">
                <Users className="size-4" aria-hidden="true" />
                Confirmación
              </p>
              <h2 className="mt-3 font-display text-3xl text-balance text-gold-soft sm:text-5xl">
                Anótate para asistir
              </h2>
              <p className="mt-4 text-pretty text-muted">
                Reserva tu lugar. El contador suma a todas las personas que van a estar en el
                aniversario.
              </p>
              <div className="gold-stroke mt-8 rounded-3xl px-6 py-7">
                <p className="text-sm tracking-widest text-muted uppercase">
                  Personas que van a asistir
                </p>
                <p className="mt-2 font-display text-6xl text-gold tabular-nums sm:text-7xl">
                  {total}
                </p>
                <p className="mt-2 text-sm text-muted">
                  {total === 0
                    ? "Sé de los primeros en anotarte."
                    : total === 1
                      ? "Ya hay una persona en camino."
                      : `Ya somos ${total} con el corazón dispuesto.`}
                </p>
              </div>
            </div>

            <div className="rounded-3xl border border-line bg-surface p-6 sm:p-8">
              {done ? (
                <div role="status" className="rise">
                  <div className="flex size-12 items-center justify-center rounded-full bg-gold text-bg-deep">
                    <Check className="size-6" aria-hidden="true" />
                  </div>
                  <h3 className="mt-5 font-display text-3xl text-gold-soft">
                    ¡Bendiciones, {savedName}!
                  </h3>
                  <p className="mt-3 text-lg text-pretty text-fg">
                    Tu lugar está confirmado. Anotaste{" "}
                    <span className="font-semibold text-gold">
                      {savedGuests} {savedGuests === 1 ? "persona" : "personas"}
                    </span>
                    .
                  </p>
                  <p className="mt-2 text-muted">
                    Ya somos {total} en Puertas Abiertas al Cielo. Te esperamos el domingo 25 de
                    octubre a las 9:00.
                  </p>
                  <button
                    type="button"
                    onClick={() => setDone(false)}
                    className="mt-6 inline-flex min-h-12 items-center justify-center rounded-full border border-line px-5 font-semibold text-fg transition-colors hover:border-gold hover:text-gold-soft"
                  >
                    Cambiar cantidad
                  </button>
                </div>
              ) : (
                <form onSubmit={onSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="nombre" className="text-sm font-medium text-fg">
                      Tu nombre
                    </label>
                    <input
                      id="nombre"
                      name="nombre"
                      autoComplete="name"
                      value={name}
                      onChange={(event) => setName(event.target.value)}
                      maxLength={60}
                      required
                      placeholder="Cómo te llamas"
                      className="mt-2 w-full rounded-xl border border-line bg-bg-deep px-4 py-3 text-fg outline-none transition-colors placeholder:text-muted/70 focus:border-gold"
                    />
                    <p className="mt-2 text-sm text-muted">
                      Tu nombre queda en este dispositivo. El contador público solo suma personas.
                    </p>
                  </div>
                  <div>
                    <p id="personas-label" className="text-sm font-medium text-fg">
                      ¿Cuántas personas van?
                    </p>
                    <div className="mt-2 flex items-center gap-3">
                      <button
                        type="button"
                        aria-label="Una persona menos"
                        onClick={() => setGuests((value) => Math.max(1, value - 1))}
                        className="inline-flex size-12 items-center justify-center rounded-full border border-line text-fg transition-colors hover:border-gold hover:text-gold"
                      >
                        <Minus className="size-4" aria-hidden="true" />
                      </button>
                      <span
                        aria-labelledby="personas-label"
                        className="min-w-16 text-center font-display text-4xl text-gold tabular-nums"
                      >
                        {guests}
                      </span>
                      <button
                        type="button"
                        aria-label="Una persona más"
                        onClick={() => setGuests((value) => Math.min(12, value + 1))}
                        className="inline-flex size-12 items-center justify-center rounded-full border border-line text-fg transition-colors hover:border-gold hover:text-gold"
                      >
                        <Plus className="size-4" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                  {error ? (
                    <p role="alert" className="text-sm text-gold-soft">
                      {error}
                    </p>
                  ) : null}
                  <button
                    type="submit"
                    disabled={busy}
                    className="inline-flex min-h-12 w-full items-center justify-center rounded-full bg-gold px-6 font-semibold text-bg-deep transition-transform duration-150 ease-out disabled:opacity-60 active:scale-[0.96]"
                  >
                    {busy ? "Anotando…" : savedName ? "Actualizar mi lugar" : "Anotarme para asistir"}
                  </button>
                </form>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-line bg-bg px-4 py-10 text-center">
        <p className="font-display text-lg tracking-wide text-gold uppercase">
          Puertas Abiertas al Cielo
        </p>
        <p className="mt-2 text-sm text-muted">
          Aniversario 16 · Pastores Patricia y Juan Melga · Batán
        </p>
      </footer>

      <WelcomeVoice />
    </div>
  );
}

function TimeCell({ value, label }: { value: string; label: string }) {
  return (
    <div className="gold-stroke rounded-2xl px-3 py-5 text-center">
      <div className="font-display text-4xl text-gold tabular-nums sm:text-6xl">{value}</div>
      <div className="mt-2 text-xs font-medium tracking-widest text-muted uppercase">{label}</div>
    </div>
  );
}

function WelcomeVoice() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const played = useRef(false);
  const [needsTap, setNeedsTap] = useState(false);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    const audio = new Audio("/bienvenida.mp3");
    audio.preload = "auto";
    audioRef.current = audio;

    const markPlaying = () => setPlaying(true);
    const markStopped = () => setPlaying(false);
    audio.addEventListener("play", markPlaying);
    audio.addEventListener("ended", markStopped);
    audio.addEventListener("pause", markStopped);

    const speakFallback = () => {
      if (typeof speechSynthesis === "undefined") return;
      const utterance = new SpeechSynthesisUtterance(WELCOME);
      utterance.lang = "es-AR";
      utterance.rate = 0.9;
      utterance.pitch = 0.7;
      const voice = speechSynthesis
        .getVoices()
        .find((item) => item.lang.toLowerCase().startsWith("es"));
      if (voice) utterance.voice = voice;
      speechSynthesis.cancel();
      speechSynthesis.speak(utterance);
      setPlaying(true);
      utterance.onend = () => setPlaying(false);
    };

    const start = async () => {
      if (played.current) return;
      try {
        await audio.play();
        played.current = true;
        setNeedsTap(false);
      } catch {
        setNeedsTap(true);
      }
    };

    audio.addEventListener("error", () => {
      if (!played.current) speakFallback();
    });

    void start();

    const unlock = () => {
      if (played.current) return;
      audio
        .play()
        .then(() => {
          played.current = true;
          setNeedsTap(false);
        })
        .catch(() => {
          speakFallback();
          played.current = true;
          setNeedsTap(false);
        });
    };
    window.addEventListener("pointerdown", unlock);

    return () => {
      window.removeEventListener("pointerdown", unlock);
      audio.pause();
      audio.removeEventListener("play", markPlaying);
      audio.removeEventListener("ended", markStopped);
      audio.removeEventListener("pause", markStopped);
    };
  }, []);

  function replay() {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
      setPlaying(false);
      return;
    }
    audio.currentTime = 0;
    audio
      .play()
      .then(() => {
        played.current = true;
        setNeedsTap(false);
      })
      .catch(() => {
        if (typeof speechSynthesis === "undefined") return;
        const utterance = new SpeechSynthesisUtterance(WELCOME);
        utterance.lang = "es-AR";
        utterance.pitch = 0.7;
        speechSynthesis.cancel();
        speechSynthesis.speak(utterance);
      });
  }

  return (
    <div className="fixed top-[4.25rem] right-3 z-50 flex max-w-[calc(100%-1.5rem)] flex-col items-end gap-2 sm:top-auto sm:right-4 sm:bottom-4">
      {needsTap ? (
        <button
          type="button"
          onClick={replay}
          className="max-w-64 rounded-2xl border border-gold/50 bg-bg/90 px-4 py-3 text-left text-sm font-medium text-gold-soft shadow-xl backdrop-blur-md"
        >
          Toca para escuchar la bienvenida
        </button>
      ) : null}
      <button
        type="button"
        onClick={replay}
        aria-label={playing ? "Detener la bienvenida" : "Escuchar la bienvenida"}
        className="inline-flex size-12 items-center justify-center rounded-full bg-gold text-bg-deep shadow-xl transition-transform duration-150 ease-out active:scale-[0.96]"
      >
        {playing ? (
          <Volume2 className="size-5" aria-hidden="true" />
        ) : (
          <VolumeX className="size-5" aria-hidden="true" />
        )}
      </button>
    </div>
  );
}
