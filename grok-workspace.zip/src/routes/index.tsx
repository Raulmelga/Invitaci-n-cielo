import { createFileRoute } from "@tanstack/react-router";
import { EventPage } from "@/components/event-page";
import { getAttendance } from "@/lib/rsvp.functions";

export const Route = createFileRoute("/")({
  loader: () => getAttendance(),
  component: Home,
});

function Home() {
  const attendance = Route.useLoaderData();
  return <EventPage initialTotal={attendance.total} />;
}
