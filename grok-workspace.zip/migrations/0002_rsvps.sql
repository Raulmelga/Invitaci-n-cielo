create table if not exists rsvps (
  token text primary key,
  guests integer not null check (guests >= 1 and guests <= 12),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
