import { o as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as MapPin, d as Check, f as CalendarDays, l as Flame, n as Volume2, o as Navigation, r as Users, s as Minus, t as VolumeX, u as Church } from "../_libs/lucide-react.mjs";
import { n as Route, r as submitRsvp } from "./router-BO006wMW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B2JdQ1l0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EVENT_AT = (/* @__PURE__ */ new Date("2026-10-25T09:00:00-03:00")).getTime();
var MAP_QUERY = "-38.005279,-57.722860";
var MAPS_EMBED = `https://maps.google.com/maps?q=${MAP_QUERY}&z=16&hl=es&output=embed`;
var MAPS_DIRECTIONS = `https://www.google.com/maps/dir/?api=1&destination=${MAP_QUERY}`;
var MAPS_OPEN = `https://www.google.com/maps/search/?api=1&query=${MAP_QUERY}`;
var WELCOME = "Bendiciones. Has entrado a la página Puertas Abiertas al Cielo. Anótese para asistir.";
var NAV = [
	{
		id: "inicio",
		label: "Inicio"
	},
	{
		id: "aniversario",
		label: "Aniversario"
	},
	{
		id: "encuentro",
		label: "Encuentro"
	},
	{
		id: "ubicacion",
		label: "Ubicación"
	},
	{
		id: "asistir",
		label: "Asistir"
	}
];
var TOKEN_KEY = "pac.token";
var NAME_KEY = "pac.name";
var GUESTS_KEY = "pac.guests";
function remain(now) {
	const diff = Math.max(0, EVENT_AT - now);
	const total = Math.floor(diff / 1e3);
	return {
		days: Math.floor(total / 86400),
		hours: Math.floor(total % 86400 / 3600),
		minutes: Math.floor(total % 3600 / 60),
		seconds: total % 60,
		done: diff <= 0
	};
}
function pad(n) {
	return String(n).padStart(2, "0");
}
function readToken() {
	const existing = localStorage.getItem(TOKEN_KEY);
	if (existing) return existing;
	const token = crypto.randomUUID();
	localStorage.setItem(TOKEN_KEY, token);
	return token;
}
function EventPage({ initialTotal }) {
	const [active, setActive] = (0, import_react.useState)("inicio");
	const [now, setNow] = (0, import_react.useState)(null);
	const [total, setTotal] = (0, import_react.useState)(initialTotal);
	const [name, setName] = (0, import_react.useState)("");
	const [guests, setGuests] = (0, import_react.useState)(1);
	const [done, setDone] = (0, import_react.useState)(false);
	const [savedName, setSavedName] = (0, import_react.useState)("");
	const [savedGuests, setSavedGuests] = (0, import_react.useState)(1);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(Date.now());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem(NAME_KEY);
		const count = Number(localStorage.getItem(GUESTS_KEY));
		const token = localStorage.getItem(TOKEN_KEY);
		if (!saved || !token || !Number.isInteger(count) || count < 1) return;
		setName(saved);
		setGuests(count);
		setSavedName(saved);
		setSavedGuests(count);
		setDone(true);
		submitRsvp({ data: {
			token,
			guests: count
		} }).then((result) => setTotal(result.total)).catch(() => {});
	}, []);
	(0, import_react.useEffect)(() => {
		const nodes = NAV.map((item) => document.getElementById(item.id)).filter((node) => Boolean(node));
		if (nodes.length === 0) return;
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			rootMargin: "-40% 0px -45% 0px",
			threshold: [
				.15,
				.4,
				.7
			]
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	async function onSubmit(event) {
		event.preventDefault();
		const trimmed = name.trim();
		if (trimmed.length < 2) {
			setError("Escribe tu nombre para anotarte.");
			return;
		}
		setBusy(true);
		setError("");
		try {
			const token = readToken();
			const result = await submitRsvp({ data: {
				token,
				guests
			} });
			localStorage.setItem(NAME_KEY, trimmed);
			localStorage.setItem(GUESTS_KEY, String(guests));
			setSavedName(trimmed);
			setSavedGuests(result.guests);
			setTotal(result.total);
			setDone(true);
		} catch (err) {
			const message = err instanceof Error ? err.message : "";
			setError(message && message.length < 140 ? message : "No pudimos anotar tu lugar. Intenta de nuevo.");
		} finally {
			setBusy(false);
		}
	}
	const clock = now === null ? null : remain(now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-svh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none fixed inset-0 -z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/hero.jpg",
					alt: "",
					className: "h-full w-full object-cover object-[center_62%]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/45" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-line/70 bg-bg/80 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#inicio",
						className: "shrink-0 font-display text-sm font-bold tracking-wide text-gold",
						children: "Al Cielo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Secciones",
						className: "flex min-w-0 flex-1 gap-1 overflow-x-auto",
						children: NAV.map((item) => {
							const on = active === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `#${item.id}`,
								"aria-current": on ? "true" : void 0,
								className: `shrink-0 rounded-full px-3 py-2 text-sm font-medium transition-colors ${on ? "bg-gold text-bg-deep" : "text-muted hover:text-fg"}`,
								children: item.label
							}, item.id);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "inicio",
					className: "scroll-mt-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto flex min-h-[calc(100svh-4.25rem)] max-w-5xl flex-col justify-end px-4 pt-6 pb-6 sm:justify-center sm:px-4 sm:pt-8 sm:pb-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rise max-w-xl rounded-3xl border border-line/80 bg-bg/70 p-5 shadow-2xl backdrop-blur-md sm:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Church, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Aniversario 16"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "gold-letters mt-3 font-display text-4xl leading-none font-bold tracking-wide uppercase sm:mt-4 sm:text-6xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block",
											children: "Puertas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block",
											children: "Abiertas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block",
											children: "al Cielo"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-md text-base text-pretty text-fg sm:mt-5 sm:text-lg",
									children: "Un encuentro con Dios en Batán. El fuego en tu corazón va a arder."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {
											className: "size-4 text-gold",
											"aria-hidden": "true"
										}), "Domingo 25 de octubre · 9:00"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
											className: "size-4 text-gold",
											"aria-hidden": "true"
										}), "Batán, Buenos Aires"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex gap-2 sm:mt-7 sm:gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#asistir",
										className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-full bg-gold px-4 text-center text-sm font-semibold text-bg-deep transition-transform duration-150 ease-out sm:px-6 sm:text-base active:scale-[0.96]",
										children: "Anotarme"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#ubicacion",
										className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-full border border-gold/60 px-4 text-center text-sm font-semibold text-gold-soft transition-transform duration-150 ease-out hover:bg-gold/10 sm:px-6 sm:text-base active:scale-[0.96]",
										children: "Cómo llegar"
									})]
								})
							]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "aniversario",
					className: "scroll-mt-20 bg-bg/85 py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-5xl px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-center text-sm font-medium tracking-widest text-gold uppercase",
								children: "Cuenta regresiva"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "anniversary-3d mx-auto mt-4 max-w-3xl text-center text-4xl sm:text-6xl md:text-7xl",
								children: "El aniversario 16"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-6 max-w-lg text-center text-pretty text-muted",
								children: "Faltan estos días para el encuentro del domingo 25 de octubre a las 9:00."
							}),
							clock?.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "status",
								className: "rise mx-auto mt-10 max-w-md rounded-2xl bg-surface px-6 py-8 text-center font-display text-2xl text-gold-soft",
								children: "El encuentro ha comenzado. Te esperamos."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4",
								role: "timer",
								"aria-label": clock ? `${clock.days} días, ${clock.hours} horas, ${clock.minutes} minutos y ${clock.seconds} segundos` : "Cargando la cuenta regresiva",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeCell, {
										value: clock ? String(clock.days) : "—",
										label: "Días"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeCell, {
										value: clock ? pad(clock.hours) : "—",
										label: "Horas"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeCell, {
										value: clock ? pad(clock.minutes) : "—",
										label: "Minutos"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeCell, {
										value: clock ? pad(clock.seconds) : "—",
										label: "Segundos"
									})
								]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "encuentro",
					className: "scroll-mt-20 bg-bg-deep/92 py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-5xl gap-8 px-4 lg:grid-cols-[1.2fr_0.8fr] lg:items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
									className: "size-4",
									"aria-hidden": "true"
								}), "El encuentro"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl text-balance text-gold-soft sm:text-5xl",
								children: "El fuego en tu corazón arderá"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 space-y-4 text-lg text-pretty text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Es un encuentro con Dios donde el fuego en tu corazón arderá." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"Cuando los hijos se juntan con un mismo sentir se produce una atmósfera donde Dios desata su ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-gold",
										children: "PODER"
									}),
									"."
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "mt-8 border-l-2 border-gold pl-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
									className: "font-display text-xl leading-snug text-pretty text-gold-soft sm:text-2xl",
									children: "«Mas si desde allí buscares a Jehová tu Dios, lo hallarás, si lo buscares de todo tu corazón y de toda tu alma.»"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
									className: "mt-3 text-sm tracking-wide text-muted uppercase",
									children: "Deuteronomio 4:29"
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "gold-stroke rounded-3xl p-6 sm:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium tracking-widest text-gold uppercase",
									children: "Pastores"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-3xl leading-tight text-fg",
									children: "Patricia y Juan Melga"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-pretty text-muted",
									children: "Te reciben en Puertas Abiertas al Cielo para el aniversario 16. Llega con el corazón dispuesto: cuando nos juntamos con un mismo sentir, el cielo se abre."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#asistir",
									className: "mt-6 inline-flex min-h-12 items-center justify-center rounded-full bg-gold px-5 font-semibold text-bg-deep transition-transform duration-150 ease-out active:scale-[0.96]",
									children: "Quiero estar ahí"
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "ubicacion",
					className: "scroll-mt-20 bg-bg/88 py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-5xl px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Ubicación"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl text-balance text-gold-soft sm:text-5xl",
								children: "Batán, Buenos Aires"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-2xl text-pretty text-muted",
								children: "Puertas Abiertas al Cielo, Iglesia de Poder de Dios. Cerca de C. los Ortiz, B7601 Batán, Provincia de Buenos Aires."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 overflow-hidden rounded-3xl border border-line bg-surface shadow-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
									title: "Mapa de Puertas Abiertas al Cielo, Batán",
									src: MAPS_EMBED,
									className: "h-80 w-full sm:h-96",
									loading: "lazy",
									referrerPolicy: "no-referrer-when-downgrade",
									allowFullScreen: true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-4 border-t border-line p-5 sm:flex-row sm:items-center sm:justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-fg",
												children: "C. los Ortiz, B7601 Batán"
											}),
											"Provincia de Buenos Aires · ",
											MAP_QUERY
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-2 sm:flex-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: MAPS_DIRECTIONS,
											target: "_blank",
											rel: "noreferrer",
											className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-gold px-5 font-semibold text-bg-deep transition-transform duration-150 ease-out active:scale-[0.96]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, {
												className: "size-4",
												"aria-hidden": "true"
											}), "Cómo llegar"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: MAPS_OPEN,
											target: "_blank",
											rel: "noreferrer",
											className: "inline-flex min-h-12 items-center justify-center rounded-full border border-line px-5 font-semibold text-fg transition-colors hover:border-gold hover:text-gold-soft",
											children: "Abrir en Maps"
										})]
									})]
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "asistir",
					className: "scroll-mt-20 bg-bg-deep/92 py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-5xl gap-8 px-4 lg:grid-cols-[0.85fr_1.15fr] lg:items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm font-medium tracking-widest text-gold uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Confirmación"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl text-balance text-gold-soft sm:text-5xl",
								children: "Anótate para asistir"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-pretty text-muted",
								children: "Reserva tu lugar. El contador suma a todas las personas que van a estar en el aniversario."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "gold-stroke mt-8 rounded-3xl px-6 py-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm tracking-widest text-muted uppercase",
										children: "Personas que van a asistir"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-6xl text-gold tabular-nums sm:text-7xl",
										children: total
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted",
										children: total === 0 ? "Sé de los primeros en anotarte." : total === 1 ? "Ya hay una persona en camino." : `Ya somos ${total} con el corazón dispuesto.`
									})
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-3xl border border-line bg-surface p-6 sm:p-8",
							children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "status",
								className: "rise",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-12 items-center justify-center rounded-full bg-gold text-bg-deep",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-6",
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "mt-5 font-display text-3xl text-gold-soft",
										children: [
											"¡Bendiciones, ",
											savedName,
											"!"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-lg text-pretty text-fg",
										children: [
											"Tu lugar está confirmado. Anotaste",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-semibold text-gold",
												children: [
													savedGuests,
													" ",
													savedGuests === 1 ? "persona" : "personas"
												]
											}),
											"."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-muted",
										children: [
											"Ya somos ",
											total,
											" en Puertas Abiertas al Cielo. Te esperamos el domingo 25 de octubre a las 9:00."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setDone(false),
										className: "mt-6 inline-flex min-h-12 items-center justify-center rounded-full border border-line px-5 font-semibold text-fg transition-colors hover:border-gold hover:text-gold-soft",
										children: "Cambiar cantidad"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit,
								className: "space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "nombre",
											className: "text-sm font-medium text-fg",
											children: "Tu nombre"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "nombre",
											name: "nombre",
											autoComplete: "name",
											value: name,
											onChange: (event) => setName(event.target.value),
											maxLength: 60,
											required: true,
											placeholder: "Cómo te llamas",
											className: "mt-2 w-full rounded-xl border border-line bg-bg-deep px-4 py-3 text-fg outline-none transition-colors placeholder:text-muted/70 focus:border-gold"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-muted",
											children: "Tu nombre queda en este dispositivo. El contador público solo suma personas."
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										id: "personas-label",
										className: "text-sm font-medium text-fg",
										children: "¿Cuántas personas van?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "Una persona menos",
												onClick: () => setGuests((value) => Math.max(1, value - 1)),
												className: "inline-flex size-12 items-center justify-center rounded-full border border-line text-fg transition-colors hover:border-gold hover:text-gold",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
													className: "size-4",
													"aria-hidden": "true"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												"aria-labelledby": "personas-label",
												className: "min-w-16 text-center font-display text-4xl text-gold tabular-nums",
												children: guests
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "Una persona más",
												onClick: () => setGuests((value) => Math.min(12, value + 1)),
												className: "inline-flex size-12 items-center justify-center rounded-full border border-line text-fg transition-colors hover:border-gold hover:text-gold",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
													className: "size-4",
													"aria-hidden": "true"
												})
											})
										]
									})] }),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										role: "alert",
										className: "text-sm text-gold-soft",
										children: error
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										disabled: busy,
										className: "inline-flex min-h-12 w-full items-center justify-center rounded-full bg-gold px-6 font-semibold text-bg-deep transition-transform duration-150 ease-out disabled:opacity-60 active:scale-[0.96]",
										children: busy ? "Anotando…" : savedName ? "Actualizar mi lugar" : "Anotarme para asistir"
									})
								]
							})
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-line bg-bg px-4 py-10 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg tracking-wide text-gold uppercase",
					children: "Puertas Abiertas al Cielo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Aniversario 16 · Pastores Patricia y Juan Melga · Batán"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeVoice, {})
		]
	});
}
function TimeCell({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "gold-stroke rounded-2xl px-3 py-5 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-4xl text-gold tabular-nums sm:text-6xl",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 text-xs font-medium tracking-widest text-muted uppercase",
			children: label
		})]
	});
}
function WelcomeVoice() {
	const audioRef = (0, import_react.useRef)(null);
	const played = (0, import_react.useRef)(false);
	const [needsTap, setNeedsTap] = (0, import_react.useState)(false);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const audio = new Audio("/bienvenida.mp3");
		audio.preload = "auto";
		audioRef.current = audio;
		const markPlaying = () => setPlaying(true);
		const markStopped = () => setPlaying(false);
		audio.addEventListener("play", markPlaying);
		audio.addEventListener("ended", markStopped);
		audio.addEventListener("pause", markStopped);
		const speakFallback = () => {
			if (typeof speechSynthesis === "undefined") return;
			const utterance = new SpeechSynthesisUtterance(WELCOME);
			utterance.lang = "es-AR";
			utterance.rate = .9;
			utterance.pitch = .7;
			const voice = speechSynthesis.getVoices().find((item) => item.lang.toLowerCase().startsWith("es"));
			if (voice) utterance.voice = voice;
			speechSynthesis.cancel();
			speechSynthesis.speak(utterance);
			setPlaying(true);
			utterance.onend = () => setPlaying(false);
		};
		const start = async () => {
			if (played.current) return;
			try {
				await audio.play();
				played.current = true;
				setNeedsTap(false);
			} catch {
				setNeedsTap(true);
			}
		};
		audio.addEventListener("error", () => {
			if (!played.current) speakFallback();
		});
		start();
		const unlock = () => {
			if (played.current) return;
			audio.play().then(() => {
				played.current = true;
				setNeedsTap(false);
			}).catch(() => {
				speakFallback();
				played.current = true;
				setNeedsTap(false);
			});
		};
		window.addEventListener("pointerdown", unlock);
		return () => {
			window.removeEventListener("pointerdown", unlock);
			audio.pause();
			audio.removeEventListener("play", markPlaying);
			audio.removeEventListener("ended", markStopped);
			audio.removeEventListener("pause", markStopped);
		};
	}, []);
	function replay() {
		const audio = audioRef.current;
		if (!audio) return;
		if (playing) {
			audio.pause();
			if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
			setPlaying(false);
			return;
		}
		audio.currentTime = 0;
		audio.play().then(() => {
			played.current = true;
			setNeedsTap(false);
		}).catch(() => {
			if (typeof speechSynthesis === "undefined") return;
			const utterance = new SpeechSynthesisUtterance(WELCOME);
			utterance.lang = "es-AR";
			utterance.pitch = .7;
			speechSynthesis.cancel();
			speechSynthesis.speak(utterance);
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed top-[4.25rem] right-3 z-50 flex max-w-[calc(100%-1.5rem)] flex-col items-end gap-2 sm:top-auto sm:right-4 sm:bottom-4",
		children: [needsTap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: replay,
			className: "max-w-64 rounded-2xl border border-gold/50 bg-bg/90 px-4 py-3 text-left text-sm font-medium text-gold-soft shadow-xl backdrop-blur-md",
			children: "Toca para escuchar la bienvenida"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: replay,
			"aria-label": playing ? "Detener la bienvenida" : "Escuchar la bienvenida",
			className: "inline-flex size-12 items-center justify-center rounded-full bg-gold text-bg-deep shadow-xl transition-transform duration-150 ease-out active:scale-[0.96]",
			children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
				className: "size-5",
				"aria-hidden": "true"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
				className: "size-5",
				"aria-hidden": "true"
			})
		})]
	});
}
function Home() {
	const attendance = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventPage, { initialTotal: attendance.total });
}
//#endregion
export { Home as component };
