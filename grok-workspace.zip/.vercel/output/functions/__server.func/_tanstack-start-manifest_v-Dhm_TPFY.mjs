//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dhm_TPFY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-odLgBHUP.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-odLgBHUP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-ug2mmAmQ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
